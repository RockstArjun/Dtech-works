import React from 'react'
import "../Assests/css/style.css"
import { Link } from "react-router-dom";

export default function Login() {
  return (
    <div className='login'>
        <Link to="/data">Login</Link>
    </div>
  )
}
