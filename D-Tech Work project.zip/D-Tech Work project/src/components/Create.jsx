import React from "react";
import { Link } from "react-router-dom";

export default function Create() {
  return (
    <div className="body">
      <div class="inputBox">
        <input type="text" required="required" />
        <span>Name</span>
      </div>
      <div class="inputBox">
        <input type="text" required="required" />
        <span>Age</span>
      </div>
      <div class="inputBox">
        <input type="text" required="required" />
        <span>Email</span>
      </div>
      <Link to="/data"><button id="btncre"> Add Data</button></Link>
    </div>
  );
}
