import React from "react";
import "../Assests/css/style.css";
import data from "./data.json"
import { Link } from "react-router-dom";
export default function TableDumb() {
  const onclick = ()=>{
    const index = data.findIndex(x => x.id === 0);
    console.log(index)
    if (index !== undefined) {data.splice(index, 1)};
  }
  return (
    <div className="content">
      <table>
        <tr>
          <th>Name</th>
          <th>Age</th>
          <th>Email</th>
        </tr>
        {data.map(e=>{
            return(
              <tr key={e.id} id="event" >
                <td>{e.name}</td>
                <td>{e.age}</td>
                <td className="dtltd">{e.email} <div>
                <button onClick={onclick}>Update</button>
                <button onClick={onclick}>Delete</button>
                  </div></td>
              </tr>
            )
        })}
      </table>
      <Link to="/create"><button id="btncre">Create Data</button></Link>
    </div>
  );
}
